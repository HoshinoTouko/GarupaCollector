'''
@File: __init__.py.py
@Author: HoshinoTouko
@License: (C) Copyright 2014 - 2017, HoshinoTouko
@Contact: i@insky.jp
@Create at: 2018/1/18 1:22
@Desc: 
'''